from fastapi import Depends, FastAPI, status, Response
from sqlalchemy.orm import Session
from .database import get_db, engine
from app import models, schemas

app = FastAPI()

models.Base.metadata.create_all(bind=engine)

@app.get("/welcome")
def welcome():
    return {"message": "Welcome the music project, the server and API are running fine."}

@app.get("/artists/", response_model=list[schemas.Artist])
def list_artists(db: Session = Depends(get_db)):
    artists = db.query(models.Artist).all()
    return artists

# @app.get("/albums/", response_model=list[schemas.Album])
# def list_albumss(db: Session = Depends(get_db)):
#     albums = db.query(models.Artist).all()
#     return albums


@app.post('/artist', status_code=status.HTTP_201_CREATED)
def create_artist(payload: schemas.ArtistCreate, db: Session = Depends(get_db)):
    artist = models.Artist(**payload.model_dump())
    db.add(artist)
    db.commit()
    db.refresh(artist)
    return artist

@app.post('/artist/{artist_id}/album', status_code=status.HTTP_201_CREATED)
def create_album(artist_id: int, payload: schemas.AlbumCreate, db: Session = Depends(get_db)):
    album = models.Album(**payload.model_dump(), album_id=artist_id)
    db.add(album)
    db.commit()
    db.refresh(album)
    return album


@app.get("/albums/{artist_id}", response_model=list[schemas.Album])
def get_artist_albums(artist_id: int,  db: Session = Depends(get_db)):
    # items = crud.get_itemss_by_user(user_id, db)
    albums = db.query(models.Album).filter(models.Album.artist_id == artist_id).all()
    return albums

